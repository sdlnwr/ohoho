//
// Created by 14169 on 2018/12/25.
//

#ifndef BOOKSTORE_CHANGE_H
#define BOOKSTORE_CHANGE_H

#include "CommandReader.h"

class change
{
private:
    int ord;
    char ordd[101];


};

#endif //BOOKSTORE_CHANGE_H
