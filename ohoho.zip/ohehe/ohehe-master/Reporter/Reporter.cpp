//
// Created by tahara on 18-12-21.
//

#include "Reporter.h"

/*
 * Since Reporter is a template class, I don't split source code from header;
 *
 */