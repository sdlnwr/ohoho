//
// Created by tahara on 18-12-25.
//

#include "UserInterface.h"

#include <iostream>
#include <cstring>
#include <time.h>

using std::cin;
using std::cout;
using std::endl;

void UserInterface::MianWindow()
{
    time_t timep;
    time(&timep);
    char tmp[64];
    strftime(tmp, sizeof(tmp), "%Y-%m-%d %H:%M:%S", localtime(&timep));

    cout << "=====================================" << endl;
    cout << "|*                                 *|" << endl;
    cout << "|*  " << tmp       << "            *|" << endl;
    cout << "|*  Welcome to bookstore system!!  *|" << endl;
    cout << "|*                                 *|" << endl;
    cout << "|*                                 *|" << endl;
    cout << "=====================================" << endl;

    cout << "Order List:" << endl;
    cout << "1: Login" << endl;
    cout << "2: Register" << endl;
    cout << "3: Buy book" << endl;
    cout << "4: Exit" << endl;

    char order[100];

    while (true)
    {
        cin >> order;
        if (strcmp(order, "1") == 0)
        {
            int t = Login();
            if(t == 1)
            {
                cout << "Order List:" << endl;
                cout << "1: Buy book" << endl;
                cout << "2: Search For book" << endl;
                cin >> order;
                if (strcmp(order, "1") == 0) Buy();
                else
                {
                    Show();
                }
            }
            else if(t ==3)
            {
                cout << "Order List:" << endl;
                cout << "1: Operations notes" << endl;
                cout << "2: Import book" << endl;
                cout << "3: About stock" << endl;
                cout << "4: Modify book" <<endl;
                if (strcmp(order, "2") == 0)
                {
                    cout << "Select a book first, please input ISBN of the book!" << endl;
                    Import();
                }
                else if (strcmp(order, "4") == 0)
                {
                    cout << "Select a book first, please input ISBN of the book!" << endl;
                    Modify();
                }
//                else if (strcmp(order, "2") == 0) Import();
            }
            else if (t == 7)
            {
                cout << "Order List:" << endl;
                cout << "1: About finance" << endl;
                cout << "2: About staff" << endl;
                cout << "3: About stock" << endl;
                cout << "4: Manage user" <<endl;
                cout << "5: Report"<<endl;
                cout << "6: Operation" <<endl;
                if (strcmp(order, "1") == 0) Finance();
                if (strcmp(order, "5") == 0) Report();
            }
        }
        else if (strcmp(order, "2") == 0)
        {
            Register();
        }
        else if (strcmp(order, "3") == 0)   Buy();
        else if (strcmp(order, "4") == 0)
        {
            cout << "Bye! Looking forward to serving you again!" << endl;
            break;
        }
    }


}

int UserInterface::Login()
{
    char user[200], password[200];
    cout << "Login: " << endl;
    cout << "User name: " << endl;
    cin >> user;
    cout << "Password: " << endl;
    cin >> password;
    char ord[400];
    int i, j;
    strcpy(ord, "su ");
    i = 3;
    for (j = 0; user[j]; j++)
    {
        ord[i++] = user[j];
    }
    ord[i++] = ' ';
    for (j = 0; password[j]; j++)
    {
        ord[i++] = password[j];
    }
    ord[i] = 0;
    int p = cmd.NextCommand(ord);
    return p;
}

void UserInterface::Register()
{
    char user[200], password[200], name[200];
    char ord[600];
    cout << "Register: " << endl;
    cout << "User name: " << endl;
    cin >> user;
    cout << "Password:" << endl;
    cin >> password;
    cout << "Name:" << endl;
    cin >> name;
    int i, j;
    strcpy(ord, "register ");
    i = 9;
    for (j = 0; user[j]; j++)
    {
        ord[i++] = user[j];
    }
    ord[i++] = ' ';
    for (j = 0; password[j]; j++)
    {
        ord[i++] = password[j];
    }
    ord[i++] = ' ';
    for (j = 0; name[j]; j++)
    {
        ord[i++] = name[j];
    }
    ord[i] = 0;
    cmd.NextCommand(ord);
}

void UserInterface::Buy()
{
    char isbn[200], qua[200];
    char ord[400];
    cout << "ISBN: " << endl;
    cin>> isbn;
    cout << "Quality:" << endl;
    cin >> qua;
    int i, j;
    strcpy(ord, "buy ");
    i = 4;
    for (j = 0; isbn[j]; j++)
    {
        ord[i++] = isbn[j];
    }
    ord[i++] = ' ';
    for (j = 0; qua[j]; j++)
    {
        ord[i++] = qua[j];
    }
    ord[i] = 0;
    cmd.NextCommand(ord);
}

void UserInterface::Show()
{
    cout<<"not yet"<<endl;
//    char isbn[200], qua[200];
//    char ord[400];
//    cout << "ISBN: " << endl;
//    cin>> isbn;
//    cout << "Quality:" << endl;
//    cin >> qua;
//    int i, j;
//    strcpy(ord, "buy ");
//    i = 4;
//    for (j = 0; isbn[j]; j++)
//    {
//        ord[i++] = isbn[j];
//    }
//    ord[i++] = ' ';
//    for (j = 0; qua[j]; j++)
//    {
//        ord[i++] = qua[j];
//    }
//    ord[i] = 0;
//    cmd.NextCommand(ord);
}

void UserInterface::Import()
{
    char isbn[200], qua[200], cost[200];
    char ord[600];
    cout << "ISBN: " << endl;
    cin >> isbn;
    cout << "Quantity: " << endl;
    cin >> qua;
    cout << "last_CostPrice(in total): " << endl;
    cin >> cost;
    int i, j;
    strcpy(ord, "import ");
    i = 7;
    for (j = 0; isbn[j]; j++)
    {
        ord[i++] = isbn[j];
    }
    ord[i++] = ' ';
    for (j = 0; qua[j]; j++)
    {
        ord[i++] = qua[j];
    }
    ord[i++] = ' ';
    for (j = 0; cost[j]; j++)
    {
        ord[i++] = cost[j];
    }
    ord[i] = 0;
    cmd.NextCommand(ord);
}

void UserInterface::Modify()
{
    char isbn[200], qua[200], cost[200];
    char ord[600];
    cout << "ISBN: " << endl;
    cin >> isbn;
    strcpy(ord, "modify ");
    int i, j;
    i = 7;

    cmd.NextCommand(ord);

}

void UserInterface::Report()
{
    //cmd.show_reporter();
//    Frecorder -> show
}

UserInterface::UserInterface()
{}
