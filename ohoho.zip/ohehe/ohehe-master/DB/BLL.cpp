//
// Created by tahara on 18-12-12.
//

#include "BLL.h"

/*
 * template class , prefer not split source code from header file.
 *
 */
