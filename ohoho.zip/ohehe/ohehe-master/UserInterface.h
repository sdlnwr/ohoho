//
// Created by tahara on 18-12-25.
//

#ifndef BOOKSTORE_USERINTERFACE_H
#define BOOKSTORE_USERINTERFACE_H

#include "CommandReader.h"

class UserInterface {
private:
    CommandReader cmd;
public:
    UserInterface();
    void MianWindow();
    int Login();
    void Register();
    void Buy();
    void Show();
    void Import();
    void Modify();
    void Report();

};


#endif //BOOKSTORE_USERINTERFACE_H
